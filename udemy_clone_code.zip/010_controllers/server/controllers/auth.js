export const register = (req, res) => {
  res.send("register user response from controller!!");
};
