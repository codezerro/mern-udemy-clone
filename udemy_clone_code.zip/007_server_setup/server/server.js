console.log("server setup");
