const TopNav = () => {
  return (
    <>
      <p>Top nav</p>
    </>
  );
};

export default TopNav;
