const Login = () => {
  return (
    <>
      <h1 className="jumbotron text-center bg-primary square">Login</h1>
      <p>login page</p>
    </>
  );
};

export default Login;
