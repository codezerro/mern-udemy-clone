const Register = () => {
  return (
    <>
      <h1 className="jumbotron text-center bg-primary square">Register</h1>
      <p>login page</p>
    </>
  );
};

export default Register;
