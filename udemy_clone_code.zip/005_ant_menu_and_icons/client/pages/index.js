const Index = () => {
  return (
    <>
      <h1 className="jumbotron text-center bg-primary square">
        Online Education Marketplace
      </h1>
      <p>from next js...</p>
    </>
  );
};

export default Index;
