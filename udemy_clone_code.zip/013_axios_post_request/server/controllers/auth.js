export const register = (req, res) => {
  console.log(req.body);
  res.json("register user response from controller!!");
};
