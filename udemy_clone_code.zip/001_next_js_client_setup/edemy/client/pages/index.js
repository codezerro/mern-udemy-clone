const Index = () => {
  return (
    <>
      <h1>Hello world</h1>
      <p>from next js...</p>
    </>
  );
};

export default Index;
